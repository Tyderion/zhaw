#ifndef ARM_PERIPHERALS_H
#define ARM_PERIPHERALS_H

#include <stdint.h>

extern int8_t apb1[];
extern int8_t apb2[];
extern int8_t ahb1[];
extern int8_t ahb2[];
extern int8_t intperiph[];
extern int8_t fmc[];

#endif