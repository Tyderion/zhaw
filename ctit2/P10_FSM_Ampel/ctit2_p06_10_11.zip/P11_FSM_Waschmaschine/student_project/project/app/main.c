/* ----------------------------------------------------------------------------
 * --  _____       ______  _____                                              -
 * -- |_   _|     |  ____|/ ____|                                             -
 * --   | |  _ __ | |__  | (___    Institute of Embedded Systems              -
 * --   | | | '_ \|  __|  \___ \   Zuercher Hochschule Winterthur             -
 * --  _| |_| | | | |____ ____) |  (University of Applied Sciences)           -
 * -- |_____|_| |_|______|_____/   8401 Winterthur, Switzerland               -
 * ----------------------------------------------------------------------------
 * --
 * -- Project     : CT2 lab - FSM washing machine
 * -- Description : Main program.
 * --
 * --               Task 1: -
 * --                       -
 * --               Task 2: -
 * --                       -
 * --               Task 3: -
 * --
 * --
 * -- $Id: main.c 3241 2016-04-20 06:18:33Z feur $
 * ------------------------------------------------------------------------- */

/* standard includes */
#include <stdint.h>
#include <reg_stm32f4xx.h>
#include <reg_ctboard.h>

/* user includes */
#include "event_handler.h"
#include "state_machine.h"
#include "timer.h"


/* -- Macros
 * ------------------------------------------------------------------------- */

#define PORT_INPUT (CT_GPIO->IN.BYTE.P1)


/* -- M A I N
 * ------------------------------------------------------------------------- */

int main(void)
{
    /// STUDENTS: To be programmed

event_t event;
	timer_init();
	fsm_init();
	while (1) {
		event = eh_get_event();
		if (event != NO_EVENT) {
			fsm_handle_event(event);
		}
		timer_wait_for_tick();
	}


    /// END: To be programmed
}

