function earth_sun3()
    ce_start = [5; 0]; 

    sun = [0; 0]; %coordinates of the sun

    Phi_rotate =  pi/180; %angle for earth orbiting the sun (arbitrarily chosen number)
    n = 300; %number of iterations

    % Rectangle Coords
    earth = create_thing_at(ce_start, 1);

    for i = 1:n
        %earth orbiting the sun
        earth = rotate_around(earth, sun, Phi_rotate);
        
        % Spin things
        earth = spin(earth, Phi_rotate);
        
        %plot
        clf
        hold on
        % Earth
        draw_thing(earth, 'red')
        
        %Sun
        plot(sun(1), sun(2), 'y*');

        set(gca,'Color','k')
        axis([-10, 10, -10, 10]);
        pause(0.0005);
    end
    
    function [thing] = create_thing_at(center, size) 
        thing.center = [center(1); center(2); 1];
        thing.topL = [center(1) - size/2; center(2) - size/2; 1];
        thing.topR = [center(1) - size/2; center(2) + size/2; 1];
        thing.botR = [center(1) + size/2; center(2) + size/2; 1];
        thing.botL = [center(1) + size/2; center(2) - size/2; 1];
    end

    function [thing] = rotate_around(obj, center, phi)
        % Rotate center
        thing.center = rotate_around_point(obj.center, center(1), center(2), phi);
        % Rotate all corners
        [thing.topL, thing.topR, thing.botR, thing.botL] = rotate_tuple(obj.topL, obj.topR, obj.botR, obj.botL, center(1), center(2), phi);
        
    end

    function [thing] = spin(thing, phi) 
        [thing.topL, thing.topR, thing.botR, thing.botL] = rotate_tuple(thing.topL, thing.topR, thing.botR, thing.botL, thing.center(1), thing.center(2), phi);
    end

    function draw_thing(thing, color) 
        plot(thing.center(1), thing.center(2), '.', 'Color', color); 
        plot([thing.topL(1), thing.topR(1)], [thing.topL(2), thing.topR(2)], 'Color', color);
        plot([thing.topR(1), thing.botR(1)], [thing.topR(2), thing.botR(2)], 'Color', color);
        plot([thing.botR(1), thing.botL(1)], [thing.botR(2), thing.botL(2)], 'Color', color);
        plot([thing.botL(1), thing.topL(1)], [thing.botL(2), thing.topL(2)], 'Color', color);
    end
end
